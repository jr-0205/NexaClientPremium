**Whimscape Leaves 1.20.2-1.21.5_r1** (2025 Apr 12)
- added cherry leaves variant texture
- changed cherry leaves texture slightly


**Whimscape Leaves 1.20.2-1.21.3_r1** (2024 Oct 26)
- added pale oak leaves
- changed acacia leaves' darkest shade slightly


**Whimscape Leaves 1.20.2-1.20.4_r1** (2024 Mar 27)
- changed pack_format to 18, added supported_formats

________________________________________________________________

**Whimscape Leaves 1.20_r1** (2023 Jun 7)
- added cherry leaves
- changed azalea flower colors slightly
- changed pack_format to 15

________________________________________________________________

**Whimscape Leaves 1.19.3_r2** (2023 Feb 19)
- changed azalea blocks slightly
- changed pack.png: small tweak


**Whimscape Leaves 1.19.3_r1** (2022 Dec 7)
- changed pack_format to 12

________________________________________________________________

**Whimscape Leaves 1.19_r2** (2023 Feb 19)
- backported changes from 1.19.3_r2


**Whimscape Leaves 1.19_r1** (2022 Oct 1)
- initial release